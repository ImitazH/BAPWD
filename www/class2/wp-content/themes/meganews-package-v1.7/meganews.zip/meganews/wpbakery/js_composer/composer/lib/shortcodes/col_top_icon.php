<?php
class WPBakeryShortCode_VC_Col_top_icon extends WPBakeryShortCode {
	public function outputTitle($title) {
        return '';
    }
}