<?php
class WPBakeryShortCode_VC_Portfolio_circles extends WPBakeryShortCode {
}