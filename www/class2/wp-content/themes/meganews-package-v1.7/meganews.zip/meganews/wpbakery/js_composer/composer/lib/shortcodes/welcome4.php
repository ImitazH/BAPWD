<?php
class WPBakeryShortCode_VC_Welcome4 extends WPBakeryShortCode {
}