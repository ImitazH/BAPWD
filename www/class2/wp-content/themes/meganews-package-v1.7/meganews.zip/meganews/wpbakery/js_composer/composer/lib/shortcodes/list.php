<?php
class WPBakeryShortCode_VC_List extends WPBakeryShortCode {
}