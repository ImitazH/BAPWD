<?php
class WPBakeryShortCode_VC_Some_text extends WPBakeryShortCode {
}