<?php
class WPBakeryShortCode_VC_Circle_chart extends WPBakeryShortCode {
}