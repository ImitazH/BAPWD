<?php
class WPBakeryShortCode_VC_Carousel extends WPBakeryShortCode {
}