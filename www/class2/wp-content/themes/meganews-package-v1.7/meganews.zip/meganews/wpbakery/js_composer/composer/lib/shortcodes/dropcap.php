<?php
class WPBakeryShortCode_VC_Dropcap extends WPBakeryShortCode {
 
}