<?php
class WPBakeryShortCode_VC_Twitter_updates extends WPBakeryShortCode {
}