<?php
class WPBakeryShortCode_VC_Col_top_icon2 extends WPBakeryShortCode {
    public function outputTitle($title) {
        return '';
    }
}