<?php
class WPBakeryShortCode_VC_Welcome2 extends WPBakeryShortCode {
}