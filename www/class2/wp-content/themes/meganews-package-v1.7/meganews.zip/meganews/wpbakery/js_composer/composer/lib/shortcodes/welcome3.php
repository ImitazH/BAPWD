<?php
class WPBakeryShortCode_VC_Welcome3 extends WPBakeryShortCode {
}