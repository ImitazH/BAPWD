<?php
class WPBakeryShortCode_VC_Pricing_column extends WPBakeryShortCode {
}