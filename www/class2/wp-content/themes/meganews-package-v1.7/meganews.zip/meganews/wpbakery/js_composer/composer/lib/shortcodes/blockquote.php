<?php
class WPBakeryShortCode_VC_Blockquote extends WPBakeryShortCode {
 
}