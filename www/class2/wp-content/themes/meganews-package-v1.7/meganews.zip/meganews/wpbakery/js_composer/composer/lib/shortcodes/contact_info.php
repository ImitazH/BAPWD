<?php
class WPBakeryShortCode_VC_Contact_info extends WPBakeryShortCode {
}
