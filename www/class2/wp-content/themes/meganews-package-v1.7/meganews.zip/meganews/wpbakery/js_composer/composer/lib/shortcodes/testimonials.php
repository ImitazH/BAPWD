<?php
class WPBakeryShortCode_VC_Testimonials extends WPBakeryShortCode {
}