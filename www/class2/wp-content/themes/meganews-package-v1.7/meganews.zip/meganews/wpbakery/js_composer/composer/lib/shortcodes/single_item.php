<?php
class WPBakeryShortCode_VC_Single_item extends WPBakeryShortCode {
}