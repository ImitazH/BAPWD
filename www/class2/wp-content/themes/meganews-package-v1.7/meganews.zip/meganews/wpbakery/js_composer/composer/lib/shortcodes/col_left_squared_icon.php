<?php
class WPBakeryShortCode_VC_Col_left_squared_icon extends WPBakeryShortCode {
    public function outputTitle($title) {
        return '';
    }
}