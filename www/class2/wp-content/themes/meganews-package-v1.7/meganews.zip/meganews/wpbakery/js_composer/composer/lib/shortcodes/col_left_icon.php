<?php
class WPBakeryShortCode_VC_Col_left_icon extends WPBakeryShortCode {

    public function outputTitle($title) {
        return '';
    }
}