<?php
class WPBakeryShortCode_VC_Services extends WPBakeryShortCode {
}