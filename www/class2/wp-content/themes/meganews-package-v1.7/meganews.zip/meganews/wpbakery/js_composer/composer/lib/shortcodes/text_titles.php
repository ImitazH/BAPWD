<?php
class WPBakeryShortCode_VC_Text_titles extends WPBakeryShortCode {


    public function outputTitle($title) {
        return '';
    }
}
?>