<?php
class WPBakeryShortCode_VC_Post_section extends WPBakeryShortCode {
}