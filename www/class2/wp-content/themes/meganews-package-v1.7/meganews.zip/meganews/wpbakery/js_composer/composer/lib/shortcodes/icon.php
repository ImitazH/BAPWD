<?php
class WPBakeryShortCode_VC_Icon extends WPBakeryShortCode {
}