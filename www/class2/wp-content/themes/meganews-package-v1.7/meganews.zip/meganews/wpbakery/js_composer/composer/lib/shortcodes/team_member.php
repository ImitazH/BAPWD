<?php
class WPBakeryShortCode_VC_Team_member extends WPBakeryShortCode {
}
