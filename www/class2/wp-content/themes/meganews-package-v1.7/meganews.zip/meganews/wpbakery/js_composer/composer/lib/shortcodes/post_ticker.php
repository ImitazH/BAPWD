<?php
class WPBakeryShortCode_VC_Post_ticker extends WPBakeryShortCode {
}